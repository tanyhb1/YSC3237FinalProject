# YSC3237FinalProject
Final Project for Software Engineering class

We are building an Android application called SnapCat for locating cats in Singapore.
SnapCat will allow users to take photos of cats that they have found around Singapore, post the picture onto the app, and create pins on shared map of Singapore so everyone can see the pictures.
Users will be able to update their profile as well as have report functionality for pictures that are not cats.
The specification for SnapCat can be found here:
https://drive.google.com/file/d/16kSYixNKuT0XzCqMHIqxHOT7Iob2-MSb/view?fbclid=IwAR3zX165RgD8QlKzIQwJS5Sr-SfAYBeszdKVANlugIiP2IX2xtKMGNyubRc